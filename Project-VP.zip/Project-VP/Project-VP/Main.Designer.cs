﻿namespace Project_VP
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ادارةبياناتالموظفينالطلابToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الاشتراكاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تسجيلدفعةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضتقريربالموظفينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تقريربالموظفينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تقريربالزبائنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تقاريرالاشتراكاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تقريربالاشتراكاتالفعالةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تقريربالاشتراكاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ادارةبياناتالموظفينالطلابToolStripMenuItem,
            this.الاشتراكاتToolStripMenuItem,
            this.تسجيلدفعةToolStripMenuItem,
            this.عرضتقريربالموظفينToolStripMenuItem,
            this.تقاريرالاشتراكاتToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1587, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ادارةبياناتالموظفينالطلابToolStripMenuItem
            // 
            this.ادارةبياناتالموظفينالطلابToolStripMenuItem.Name = "ادارةبياناتالموظفينالطلابToolStripMenuItem";
            this.ادارةبياناتالموظفينالطلابToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.ادارةبياناتالموظفينالطلابToolStripMenuItem.Text = "ادارة بيانات الموظفين/الطلاب";
            this.ادارةبياناتالموظفينالطلابToolStripMenuItem.Click += new System.EventHandler(this.ادارةبياناتالموظفينالطلابToolStripMenuItem_Click);
            // 
            // الاشتراكاتToolStripMenuItem
            // 
            this.الاشتراكاتToolStripMenuItem.Name = "الاشتراكاتToolStripMenuItem";
            this.الاشتراكاتToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
            this.الاشتراكاتToolStripMenuItem.Text = "الاشتراكات";
            this.الاشتراكاتToolStripMenuItem.Click += new System.EventHandler(this.الاشتراكاتToolStripMenuItem_Click);
            // 
            // تسجيلدفعةToolStripMenuItem
            // 
            this.تسجيلدفعةToolStripMenuItem.Name = "تسجيلدفعةToolStripMenuItem";
            this.تسجيلدفعةToolStripMenuItem.Size = new System.Drawing.Size(106, 24);
            this.تسجيلدفعةToolStripMenuItem.Text = "ادارة الدفعات";
            this.تسجيلدفعةToolStripMenuItem.Click += new System.EventHandler(this.تسجيلدفعةToolStripMenuItem_Click);
            // 
            // عرضتقريربالموظفينToolStripMenuItem
            // 
            this.عرضتقريربالموظفينToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تقريربالموظفينToolStripMenuItem,
            this.تقريربالزبائنToolStripMenuItem});
            this.عرضتقريربالموظفينToolStripMenuItem.Name = "عرضتقريربالموظفينToolStripMenuItem";
            this.عرضتقريربالموظفينToolStripMenuItem.Size = new System.Drawing.Size(137, 24);
            this.عرضتقريربالموظفينToolStripMenuItem.Text = "تقارير المستخدمين";
            this.عرضتقريربالموظفينToolStripMenuItem.Click += new System.EventHandler(this.عرضتقريربالموظفينToolStripMenuItem_Click);
            // 
            // تقريربالموظفينToolStripMenuItem
            // 
            this.تقريربالموظفينToolStripMenuItem.Name = "تقريربالموظفينToolStripMenuItem";
            this.تقريربالموظفينToolStripMenuItem.Size = new System.Drawing.Size(186, 26);
            this.تقريربالموظفينToolStripMenuItem.Text = "تقرير بالزبائن";
            this.تقريربالموظفينToolStripMenuItem.Click += new System.EventHandler(this.تقريربالموظفينToolStripMenuItem_Click);
            // 
            // تقريربالزبائنToolStripMenuItem
            // 
            this.تقريربالزبائنToolStripMenuItem.Name = "تقريربالزبائنToolStripMenuItem";
            this.تقريربالزبائنToolStripMenuItem.Size = new System.Drawing.Size(186, 26);
            this.تقريربالزبائنToolStripMenuItem.Text = "تقرير بالموظفين";
            this.تقريربالزبائنToolStripMenuItem.Click += new System.EventHandler(this.تقريربالزبائنToolStripMenuItem_Click);
            // 
            // تقاريرالاشتراكاتToolStripMenuItem
            // 
            this.تقاريرالاشتراكاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تقريربالاشتراكاتالفعالةToolStripMenuItem,
            this.تقريربالاشتراكاتToolStripMenuItem});
            this.تقاريرالاشتراكاتToolStripMenuItem.Name = "تقاريرالاشتراكاتToolStripMenuItem";
            this.تقاريرالاشتراكاتToolStripMenuItem.Size = new System.Drawing.Size(126, 24);
            this.تقاريرالاشتراكاتToolStripMenuItem.Text = "تقارير الاشتراكات";
            this.تقاريرالاشتراكاتToolStripMenuItem.Click += new System.EventHandler(this.تقاريرالاشتراكاتToolStripMenuItem_Click);
            // 
            // تقريربالاشتراكاتالفعالةToolStripMenuItem
            // 
            this.تقريربالاشتراكاتالفعالةToolStripMenuItem.Name = "تقريربالاشتراكاتالفعالةToolStripMenuItem";
            this.تقريربالاشتراكاتالفعالةToolStripMenuItem.Size = new System.Drawing.Size(297, 26);
            this.تقريربالاشتراكاتالفعالةToolStripMenuItem.Text = "تقرير بالاشتراكات الفعالة";
            this.تقريربالاشتراكاتالفعالةToolStripMenuItem.Click += new System.EventHandler(this.تقريربالاشتراكاتالفعالةToolStripMenuItem_Click);
            // 
            // تقريربالاشتراكاتToolStripMenuItem
            // 
            this.تقريربالاشتراكاتToolStripMenuItem.Name = "تقريربالاشتراكاتToolStripMenuItem";
            this.تقريربالاشتراكاتToolStripMenuItem.Size = new System.Drawing.Size(297, 26);
            this.تقريربالاشتراكاتToolStripMenuItem.Text = "تقرير بالاشتراكات بدون دفعة مالية";
            this.تقريربالاشتراكاتToolStripMenuItem.Click += new System.EventHandler(this.تقريربالاشتراكاتToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(680, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(342, 55);
            this.label1.TabIndex = 7;
            this.label1.Text = "النادي الرياضي - جامعة الخليل";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1587, 731);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Name = "Main";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "Main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ادارةبياناتالموظفينالطلابToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الاشتراكاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تسجيلدفعةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضتقريربالموظفينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تقريربالموظفينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تقريربالزبائنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تقاريرالاشتراكاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تقريربالاشتراكاتالفعالةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تقريربالاشتراكاتToolStripMenuItem;
        private System.Windows.Forms.Label label1;
    }
}