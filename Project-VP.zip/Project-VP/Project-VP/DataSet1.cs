﻿namespace Project_VP
{


    partial class DataSet1
    {
    }
}

namespace Project_VP.DataSet1TableAdapters {
    
    
    public partial class SubsTableAdapter {
    }
}
